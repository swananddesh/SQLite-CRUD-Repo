package com.krixi.sqlitecrud;

/**
 * Created by KS114 on 8/4/16.
 */
public class Employee
{
    int id;
    String empName;
    String empEmail;
    String empRelocate;

    public Employee()
    {

    }
}
